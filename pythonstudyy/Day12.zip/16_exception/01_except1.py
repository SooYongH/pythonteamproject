# 예외처리문 : try~except

# try:
#     print(10/0)
#     # print('나이:'+ 23 +'살')
# except:
#     print('오류발생')
#
# try:
#     print(10/0)
#     # print('나이:'+ 23 +'살')
# except Exception:
#     print('오류발생')

try:
    print(10/0)
    # print('나이:'+ 23 +'살')
except ZeroDivisionError:
    print('0으로 나눌 수 없습니다')

try:
    # print(10/0)
    print('나이:'+ 23 +'살')
except TypeError:
    print('정수를 문자열과 더할 수 없어요')

try:
    # print(10/0)
    print('나이:'+ 23 +'살')
except TypeError as e:  # e :에러 메시지변수
    print('정수를 문자열과 더할 수 없어요', e)

