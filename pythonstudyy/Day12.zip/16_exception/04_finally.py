# try~except~else~finally

try:
    f=open('exception.txt', 'r')
except FileNotFoundError:
    pass
else:
    data = f.read()
    print(data)
    f.close()
finally:
    print('종료')