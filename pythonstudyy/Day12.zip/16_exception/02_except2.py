
a = [1,2,3]

try:
    print(10/0)
    print(a[4])
except IndexError as e :
    print('인덱스 범위를 벗어났어요:', e)
except ZeroDivisionError as e:
    print('0으로 나눌수없어요:', e)