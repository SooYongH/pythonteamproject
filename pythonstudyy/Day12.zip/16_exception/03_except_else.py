# try~except~else문

try:
    num = int(input('숫자입력: '))
except ValueError as e:
    print('숫자가아닙니다:', e)
else:
    print(num)


try:
    f = open('exception.txt', 'r')
except FileNotFoundError:
    pass
else:
    data = f.read()
    print(data)
    f.close()

print('종료')