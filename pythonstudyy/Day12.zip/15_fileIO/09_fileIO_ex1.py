# for문 이용하여 다음의 내용을 갖는 텍스트 파일(outfile3.txt)을 출력하기
#
# 1행
# 2행
# 3행
#
#
# 10행

f = open('data/outfile3.txt', 'w', encoding='utf-8')
s = ''
for i in range(1, 11):
    s += str(i)+'행\n'
f.write(s)
f.close()

f = open('outfile3.txt', 'w', encoding='utf-8')
str_out=''
for txt in range(1, 11):
    str_out = str(txt) + '행\n'
    f.write(str_out)
f.close()
