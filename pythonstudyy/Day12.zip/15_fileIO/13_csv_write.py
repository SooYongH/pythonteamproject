# csv 파일쓰기

import csv

data_list = [['id', '국어', '영어', '수학'],
             ['1', 90, 100, 50],
             ['2', 100, 50, 70]]

# f = open('data/outfile5.csv', 'w', newline='')
# csvobj = csv.writer(f, delimiter=',')
# csvobj.writerows(data_list)
# f.close()

# with open('data/outfile5.csv', 'w', newline='') as f:
#     csvobj = csv.writer(f, delimiter=',')
#     csvobj.writerows(data_list)

def writecsv(filename, data_list):
    with open(filename, 'w', newline='') as f:
        csvobj = csv.writer(f, delimiter=',')
        csvobj.writerows(data_list)

writecsv('data/outfile5.csv', data_list)
