# csv 파일 읽고 쓰기 모듈

import csv

def opencsv(filename, encode='utf-8'):
    f = open(filename, 'r', encoding=encode)
    data = csv.reader(f)
    data_list = []
    for d in data:
        data_list.append(d)
    f.close()
    return data_list

def writecsv(filename, data_list, encode='utf-8'):
    with open(filename, 'w', newline='', encoding=encode) as f:
        csvobj = csv.writer(f, delimiter=',')
        csvobj.writerows(data_list)

if __name__ == '__main__':
    print('csv 읽고쓰기 파일입니다.')