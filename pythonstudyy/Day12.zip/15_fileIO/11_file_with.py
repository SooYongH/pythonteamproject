# with문을 사용한 파일입력 & 출력

# with open('data/study.txt', 'r', encoding='utf-8') as f:
#     text = f.read()
#     print(text)

with open('data/outfile4.txt', 'a') as f2:
    f2.write('\nPython')

with open('data/outfile4.txt', 'r') as f3:
    print(f3.read())
