# 파일전체 읽기 : readline()

f = open('data/study.txt', 'r', encoding='utf-8')

while True:
    line = f.readline()
    if not line:   # 파일의 끝
        break
    print(line)

f.close()