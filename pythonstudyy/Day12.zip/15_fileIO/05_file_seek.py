# 파일 내에서 검색 : seek(offset, whence) 함수
# offset : 상대위치
# whence : 0 시작위치, 1 현재위치  2 파일의끝
# sample.txt : utf-8형식으로 저장

f = open('data/sample.txt', 'r', encoding='utf-8')

# 0행 0열에서 시작
f.seek(0,0)  # 시작위치 : 0행 0열
lines = f.readlines()
print(lines)

f.seek(4,0)
lines = f.readlines()
print(lines)

f.seek(14,0)
lines = f.readlines()
print(lines)

# 한글의 경우 utf-8은 3바이트가 한문자
# utf-16 : 2바이트가 한문자

f.seek(17,0)
lines = f.readlines()
print(lines)
f.close()

