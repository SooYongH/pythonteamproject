import usecsv

data_list = [['id', '국어', '영어', '수학'],
             ['1', 90, 100, 50],
             ['2', 100, 50, 70],
             ['3', 50, 80, 60]]

usecsv.writecsv('data/outfile5.csv', data_list)

data = usecsv.opencsv('data/outfile5.csv')
print(data)
