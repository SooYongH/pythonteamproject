# csv 파일읽기
import csv

# with open('data/sample3.csv', 'r', encoding='utf-8') as f:
#     # print(f.read())
#     data = csv.reader(f)
#     print(data)
#
#     for x in data:
#         print(x)

# f = open('data/sample3.csv', 'r', encoding='utf-8')
# data = csv.reader(f)
# data_list = []
# for x in data:
#     data_list.append(x)
# print(data_list)
# f.close()

def opencsv(filename, encode='utf-8'):
    f = open(filename, 'r', encoding=encode)
    data = csv.reader(f)
    data_list = []
    for d in data:
        data_list.append(d)
    f.close()
    return data_list

data = opencsv('data/sample3.csv')
print(data)