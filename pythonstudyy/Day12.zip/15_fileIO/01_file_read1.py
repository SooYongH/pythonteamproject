# 텍스트파일 읽기 : read()

# 1. 파일열기(읽기모드) :  파일객체 생성
f = open('data/study.txt', 'r', encoding='utf-8')
# f = open('data/study.txt', 'r')

# 2. 파일읽기
text = f.read()
# read() : 1개의 문자열로 전체 내용을 읽어옴
print(text)

# 3. 파일닫기
f.close()