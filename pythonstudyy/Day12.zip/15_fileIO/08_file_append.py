# 파일쓰기모드 : 'a' => append 뒤에붙여쓰기

f = open('data/outfile2.txt', 'a')
s = input('문자열 입력: ')
f.write(s)
f.close()