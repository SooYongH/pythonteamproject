# 파일쓰기 : writelines()

list1 = ['HI\n','Hello','Apple', '100\n', '200']

f = open('data/outfile4.txt','w')
f.writelines(list1)
f.close()