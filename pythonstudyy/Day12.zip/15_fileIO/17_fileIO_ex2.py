# 연습문제

# s.txt

with open('data/s.txt', 'r') as f:
    data = f.readlines()
    # print(data)
    o_data = sorted(data)

with open('data/s_out.txt', 'w') as f2:
    f2.writelines(o_data)
