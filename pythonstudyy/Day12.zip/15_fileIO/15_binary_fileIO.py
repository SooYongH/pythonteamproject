# 이진파일 읽고 쓰기

inF = open('data/sample.PNG', 'rb')
outF = open('copy.PNG', 'wb')

while True:
    inS = inF.read(1)
    if not inS:
        break
    outF.write(inS)

inF.close()
outF.close()
