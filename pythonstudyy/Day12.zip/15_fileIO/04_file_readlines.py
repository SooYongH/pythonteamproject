# 텍스트파일 읽기 : readlines()

f = open('data/study.txt', 'r', encoding='utf-8')
lines = f.readlines()
# print(lines)
# print(type(lines))
# print(len(lines))
for line in lines:
    # print(line, end='')
    print(line.strip('\n'))
f.close()

f2 = open('data/study.txt', 'r', encoding='utf-8')
for line in f2:
    print(line, end='')
f2.close()